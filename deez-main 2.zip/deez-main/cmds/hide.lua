return function()
    local player = game:service"Players".LocalPlayer
    local pos = CFrame.new(-163,54,216)
    player.Character.HumanoidRootPart.CFrame = pos
end
